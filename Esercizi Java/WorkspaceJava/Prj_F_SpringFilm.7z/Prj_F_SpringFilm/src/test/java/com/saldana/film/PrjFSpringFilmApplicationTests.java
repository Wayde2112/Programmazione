package com.saldana.film;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjFSpringFilmApplicationTests {

	@Test
	void contextLoads() {
	}

}

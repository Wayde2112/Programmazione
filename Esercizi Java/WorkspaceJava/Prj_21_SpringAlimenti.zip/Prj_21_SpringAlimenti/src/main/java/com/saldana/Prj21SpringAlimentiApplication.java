package com.saldana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prj21SpringAlimentiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Prj21SpringAlimentiApplication.class, args);
	}

}

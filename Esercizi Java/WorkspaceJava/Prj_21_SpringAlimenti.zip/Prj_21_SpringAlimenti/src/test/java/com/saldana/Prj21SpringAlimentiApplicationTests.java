package com.saldana;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj21SpringAlimentiApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.saldana.ricette;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj23RicetteApplicationTests {

	@Test
	void contextLoads() {
	}

}

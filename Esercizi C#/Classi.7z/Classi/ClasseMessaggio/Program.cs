﻿using System;

namespace ClasseMessaggio
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * Realizzare un programma che consenta la gestione di email
             * 
             * Ogni mail deve contenere i seguenti dati:
             * 
             * A (obbligatorio)
             * DA (obbligatorio)
             * CC (facoltativo)
             * CCN (facoltativo)
             * Oggetto (obbligatorio)
             * Messaggio (obbligatorio)
             * Priorità (obbligatorio)
            */
        }
    }
}

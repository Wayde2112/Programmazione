﻿using System;

namespace ClasseTriangolo
{
    class Program
    {
        static void Main(string[] args)
        {
            var t = new Triangolo();
            Console.Write("Lato 1: ");
            t.Lato1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Lato 2: ");
            t.Lato2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Lato 3: ");
            t.Lato3 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine(t.ToString());

        }

    }
}

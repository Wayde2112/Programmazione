const notes = [
    {
        "uuid": "e1960fc6-4d45-4b10-a333-7f90041e17c7",
        "user": "spacex",
        "date": "2022-05-20",
        "title": "Corso Node",
        "body": "Crea app Note"
    },
    {
        "uuid": "8be856f4-67d5-4c3f-95bd-e98e00799bb3",
        "user": "puppy",
        "date": "2022-05-11",
        "title": "Corso Node",
        "body": "Crea app Note"
    },
    {
        "uuid": "e8721372-1534-415c-ab7a-4cbc64a84ca3",
        "user": "juice",
        "date": "2022-05-10",
        "title": "Corso Node",
        "body": "Crea app Note"
    },
    {
        "uuid": "52a7d21c-d85c-4c08-ab94-d8dd59162e8a",
        "user": "spacex",
        "date": "2022-05-21",
        "title": "Corso PHP",
        "body": "Crea app Note"
    },
    {
        "uuid": "4d657718-c914-45ed-97a0-8c15b8104277",
        "user": "juice",
        "date": "2022-05-23",
        "title": "Corso C#",
        "body": "Crea app Note"
    },
    {
        "uuid": "941330b9-3a8b-4728-951a-f27a43045a9c",
        "user": "blackwindow",
        "date": "2022-05-20",
        "title": "Corso Node",
        "body": "Crea app Note"
    }
];

export default notes;